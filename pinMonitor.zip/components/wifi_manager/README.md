# Wi-Fi Manager Component

This component provides a modular state machine for managing Wi-Fi connectivity